file="F"$1"_1KB.txt"
for num in $(seq 1 3)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_2KB.txt"
for num in $(seq 1 6)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_3KB.txt"
for num in $(seq 1 9)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_4KB.txt"
for num in $(seq 1 12)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_5KB.txt"
for num in $(seq 1 15)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_6KB.txt"
for num in $(seq 1 18)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_7KB.txt"
for num in $(seq 1 21)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_8kb.txt"
for num in $(seq 1 24)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_9KB.txt"
for num in $(seq 1 27)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_10KB.txt"
for num in $(seq 1 30)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done

file="F"$1"_100kb.txt"
for num in $(seq 1 300)
do
    echo "A cloud is a computing capability that provides an abstraction between the computing resource and its underlying technical architecture enabling convenient demand network access to a shared pool of configurable  computing resources that can be rapidly provisioned and released with minimal management effort or service provide interaction NIST" >> $file
done
